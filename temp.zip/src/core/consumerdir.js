const path = require('path')
const electronpath = require('electron').remote.app.getAppPath()
export default  ( path.join(electronpath, '../', '/Consumer'))