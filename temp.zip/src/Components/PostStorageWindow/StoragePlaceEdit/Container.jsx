import React from 'react'
import { connect } from 'react-redux';
import StoragePlaceEditMenu from './StoragePlaceEditMenu'
import {reduxForm} from 'redux-form'
import {addStorePlaceToFulesSypAC,addNewPartStorePlaceToFulesSypAC,addToStikerWindowAC} from './../../../Redux/PostStorageReducer'
import {fromStoragePlace} from './../../../Redux/FileReducer'
import { formValueSelector } from 'redux-form'


const selector = formValueSelector('selectingRequestStoragePlace')

const StoragePlaceEditMenuC = (props)=>{
  const [copiedtobuffer, setCopiedtobuffer]=React.useState({place: false, cunsumer:false})
  console.log(props)

  function unique(arr) {
    let result = [];
    for (let str of arr) {
      if (!result.includes(str)) {
        result.push(str);
      }
    }
    return result;
  }

  function addClipboard(e,text, id) {
    e.preventDefault()
    console.log(id)
    navigator.clipboard.writeText(text)
    .then((a) => {
      if(id === 'cunsumer'){
      setCopiedtobuffer({cunsumer: true, place: false})
    }else if(id === 'place'){
      setCopiedtobuffer({cunsumer: false, place: true})
    }
    })
    .catch(err => {
      console.log('Something went wrong', err);
    });
  }

  const dosmt = async (data) =>{
    if(window.confirm(`Для запроса ${data.request} выбран поставщик <${data.customer}>   применить?` )){
       await props.addStorePlaceToFulesSypAction(data)
       await props.addToStikerWindow(data)
       await props.reset()
       setCopiedtobuffer({cunsumer: false})
    } else console.log('не приминилось')
  }
const dosmt2 = async (data) =>{
  console.log(data)
  if(window.confirm(`Для номера ${data.hasNoPlace} выбрано место  <${data.place}>   применить?` )){
    await props.addNewPartStorePlaceToFulesSyp(data)
    await props.addToStikerWindow(data)
    await props.reset()
    setCopiedtobuffer({ place: false})
 } else console.log('не приминилось')
}
const toprintwindow = async(data) =>{
  await props.addToStikerWindowPath(data)
  console.log('добавленно')
}

  return(
    <StoragePlaceEditMenu
    unique={unique}
    addClipboard={addClipboard}
    aprops={props} 
    dosmt2={dosmt2}
    dosmt={dosmt}
    copiedtobuffer={copiedtobuffer}
    toprintwindow={toprintwindow}
    />
  )
}


const mapStateToProps = (state) =>{
  const requestValue = selector(state, 'request')
  const hasNoPlaceValue = selector(state, 'hasNoPlace')
  return{
    filesSupplying: state.PostStorageReducer.filesSupplying,
    customer:state.customerReducer.customer,
    requestValue,hasNoPlaceValue,
    outStikers:state.PostStorageReducer.outStikers,
    outStikersPath: state.fileReducer.files
  }
}
const mapDispatchToProps = (dispatch) =>{
  return{
    addStorePlaceToFulesSypAction: (values) =>{
      dispatch(addStorePlaceToFulesSypAC(values))
    },
    addNewPartStorePlaceToFulesSyp: (values) =>{
      dispatch(addNewPartStorePlaceToFulesSypAC(values))
    },
    addToStikerWindow: (values) =>{
      dispatch(addToStikerWindowAC(values))
    },
    addToStikerWindowPath:(values) =>{
      dispatch(fromStoragePlace(values))
    },
  }
}

const StoragePlaceEditMenuContainer = connect (mapStateToProps, mapDispatchToProps)(StoragePlaceEditMenuC);

const StoragePlaceEditMenuContainerReduxFrom = reduxForm({
  form: 'selectingRequestStoragePlace',
})(StoragePlaceEditMenuContainer);

export default StoragePlaceEditMenuContainerReduxFrom