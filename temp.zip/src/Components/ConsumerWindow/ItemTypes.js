export default {
  CARD: 'card',
}
