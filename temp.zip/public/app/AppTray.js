const electron = require('electron');
const { Tray,app, Menu,ipcMain } = require('electron')

class AppTray extends Tray{
  constructor(iconPath, mainWindow){
    super(iconPath);

    this.mainWindow = mainWindow
    this.on('click', this.onClick.bind(this));
    this.on('right-click', this.onRightClick.bind(this));
  }
  
  onClick(event , bounds){
    const { x,y } = bounds
    const {height , width} = this.mainWindow.getBounds();
    const yPosition = process.platform === 'darwin' ?  y : y - height
    if (this.mainWindow.isVisible()) {
      this.mainWindow.hide()
    } else {
      this.mainWindow.setBounds({
        x: x - width/2,
        y: yPosition,
        height: height, 
        width:width , 
      })
      this.mainWindow.show()
    }
  }
  onRightClick(){
    let contextMenu  = Menu.buildFromTemplate([
     {
       label: 'Добавить наклейку',
      //  click: ()=> this.mainWindow.alert('В разработке')
     },
     { type: 'separator' },
     {
       label: 'Закрыть',
       click: ()=> app.quit()
     }
    ])
       this.popUpContextMenu(contextMenu)
  }
}

module.exports = AppTray